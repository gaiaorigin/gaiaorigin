try: returnedHosts = [('orion', i[1]) if i[0] == 'orionoid' else i for i in returnedHosts]
except: pass
