__author__ = 'bromix'

from youtube_plugin.kodion import service

service.run()
